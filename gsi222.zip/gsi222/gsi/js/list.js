$(function(){
	$('.text_xs1').hide ();
	$('h2.title_text_xs1').click(function(){
		$(this).next().slideToggle('slow');
	});
});

$(function(){
	$('.text_xs2').hide ();
	$('h2.title_text_xs2').click(function(){
		$(this).next().slideToggle('slow');
	});
});