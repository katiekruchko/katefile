		<footer id="footer" class="footer">
		  	<div class="footer__a">
		  			<div class="container text-left">
					    <div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">
								<p class="footer__content_1">ВАЖНО ЗНАТЬ</p>
								<a class="text-muted" href="kakoi_kamin_vam_nushen.php">Какой вам нужен камин</a><br>
								<a class="text-muted" href="kopii_brendov.php">Копии брендов</a><br>
								<a class="text-muted" href="kaminnie_topki.php">Каминные топки</a><br>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">
									<p class="footer__content">Производство</p>
									<a class="text-muted" href="nashe_oborudovanie.php">Наше оборудование</a><br>
									<a class="text-muted" href="realizacia_zacaza.php">Реализация заказа</a><br>
									<a class="text-muted" href="garantii.php">Гарантии</a><br>
						    </div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<p class="footer__content">КОНТАКТЫ</p>
								<p class="footer_contakt">г. Минск,220124, ул Лынькова, д. 85, крп.6, пом. 1, ком. 18,
									УНП 192568767 в Приорбанк ОАО, ЦБУ 109, код 749 р/с 301204235019
									</p>
							</div>
					    </div>
		   			</div>
		    </div>
			<div class="cintainer text-center footer__polosa-black">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-5">
						<a href="index.php">
						 <p class="footer__stoletov"> &#169 kaminov.by 2018</p>
						</a>
					</div>
					<div class="footer__social">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-7">
						 <ul>
							<a class="fa fa-youtube fa-lg"></a>
		                    <a class="fa fa-vk fa-lg"></a>
		                    <a class="fa fa-facebook fa-lg"></a>
		                    <a class="fa fa-instagram fa-lg"></a>                         
		                 </ul>
					</div>
					</div>
				</div>
			</div>
		 </footer>
			  <!-- jQuery -->
			  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
			  <!-- Latest compiled and minified JavaScript -->
			  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
			  <script type="text/JavaScript" src="js/list.js"></script>
	
	</div>
</body>
</html>
		