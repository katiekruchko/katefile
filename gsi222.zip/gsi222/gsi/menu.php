			<nav class="navbar navbar-inverse" id="menu">
				 <div class="container">
					<div class="navbar-header">
						 <button type="button" id="menu__btn" class="navbar-toggle" data-toggle="collapse" data-target="#responsive-menu">
					                            <span class="icon-bar"></span>
					                            <span class="icon-bar"></span>
					                            <span class="icon-bar"></span>   
					      </button>
					</div>
					<div class="collapse navbar-collapse" id="responsive-menu">
						<div class="container" id="responsive-menu__btn">
							<div class="row-fluid">
								<ul class="nav navbar-nav">
									<li class="active"><a href="index.php">Главная</a style="color: #fff;"></li>
									<li><a href="about.php" style="color: #fff;">О нас</a></li>
									<li><a href="portfolio.php" style="color: #fff;">Портфолио</a></li>
									<li class="dropdown">
										<a href="portali_oblicovki.php" class="dropdown-toggle" data-toggle="dropdown" style="color: #fff;">Порталы и облицовки</a>
										<ul class="dropdown-menu" id="dropdown-menu">
											<li><a href="#">Godin</a></li>
											<li><a href="#">Cheminees Philippe</a></li>
											<li><a href="#">Diffusion</a></li>
										</ul>
									</li>
									<li><a href="video_s_nashih_obectov.php" style="color: #fff;">Видео</a></li>
									<li><a href="material.php" style="color: #fff;">Материал</a></li>
									<li><a href="contacts.php" style="color: #fff;">Контакты</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</nav>